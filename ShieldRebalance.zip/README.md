# Work in progress!!!

This mod is designed to rebalance OSP and shields. It is still a work in progress.

The concept is to trigger OSP under the following conditions:
- When you have any% shields
- If you don't have shields, it will trigger if you have >90% health

So far all it does it spit out a chat message if OSP triggers. Logic is still a WIP.

## Changelog
- v0.1.0 Initial release, main feature not implemented.
- v0.1.1 A shot in the dark for working logic. I figured out crits are wonky so it doesn't trigger correctly.
- v0.1.2 Reworked the system for checking if you have shields. Now checks if you had shields at the start of the update like it should.
